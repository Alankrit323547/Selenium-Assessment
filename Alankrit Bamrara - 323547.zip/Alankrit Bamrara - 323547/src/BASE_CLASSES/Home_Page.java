package BASE_CLASSES;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Home_Page {
	WebDriver dr;
	Logger log;
	
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td[1]/form/table[1]/tbody/tr/th")
	WebElement text;
	
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select")
	WebElement category_list;
	
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[2]/td/input")
	WebElement kwd;
	
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[3]/td/input")
	WebElement btn;
	
	public Home_Page(WebDriver dr, Logger log)
	{
		this.dr=dr;
		this.log=log;
		PageFactory.initElements(dr, this);
	}
	public void create_log(String meth_name, String exp_res, String act_res, String test_res)
	{
		if(test_res.compareTo("PASS")==0)
		{
			if(exp_res=="")
				log.info("Method "+ meth_name+" invoked \n"+"TC_ID: TESTNG_TESTS.testng_test_1#"+meth_name+"\n ====================================================================================");
			else
				log.info("Method "+ meth_name+" invoked \n"+"TC_ID: TESTNG_TESTS.testng_test_1#"+meth_name+"\nExpected Result: "+exp_res+"\nActual Result: "+act_res+"\nTest Result: "+test_res+"\n ====================================================================================");
	
		}
		else {
			if(exp_res=="")
				log.info("Method "+ meth_name+" invoked \n"+"TC_ID: TESTNG_TESTS.testng_test_1#"+meth_name+"\n ====================================================================================");
			else
				log.info("Method "+ meth_name+"\n"+"TC_ID: TESTNG_TESTS.testng_test_1#"+meth_name+"\nExpected Result: "+exp_res+"\nActual Result: "+act_res+"\nTest Result: "+test_res+"\n ====================================================================================");
		}
	}
	public String return_title()
	{
		 WebDriverWait wt = new WebDriverWait(dr,10);                             
		 wt.until(ExpectedConditions.elementToBeClickable(btn));
		return dr.getTitle();
	}
	public String return_txt()
	{
		return text.getText();
	}
	public String input_data(String category, String keyword)
	{
		try
		{
			Select sel = new Select(category_list);
			sel.selectByVisibleText(category);
			kwd.sendKeys(keyword);
			btn.click();
			return "Clicked Search";
		}
		catch (Exception e)
		{
			return "Not Clicked Search";
		}
	}
}
