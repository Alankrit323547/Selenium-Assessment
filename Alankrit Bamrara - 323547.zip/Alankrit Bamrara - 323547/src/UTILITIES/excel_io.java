package UTILITIES;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_io {
	public product read_excel_1(int r , String sheet)
	{
		product obj = new product();
		try {
		File f = new File("data.xlsx");
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet(sheet);
		XSSFRow row = sh.getRow(r);
		XSSFCell cell_category = row.getCell(0);
		obj.category = cell_category.getStringCellValue();
		XSSFCell cell_str = row.getCell(1);
		obj.search_str = cell_str.getStringCellValue();
		XSSFCell cell_quantity = row.getCell(2);
		obj.quantity = (int)cell_quantity.getNumericCellValue();
		return obj;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return obj;
	}
	public expected_products read_excel_2(int r, String sheet)
	{
		expected_products obj = new expected_products();
		try {
		File f = new File("data.xlsx");
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet(sheet);
		XSSFRow row = sh.getRow(r);
		XSSFCell cell_prod = row.getCell(0);
		obj.product_name = cell_prod.getStringCellValue();
		XSSFCell cell_total = row.getCell(1);
		obj.total = (float) cell_total.getNumericCellValue();
		return obj;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return obj;
	}
}
