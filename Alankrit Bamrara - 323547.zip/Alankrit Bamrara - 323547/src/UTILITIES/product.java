package UTILITIES;

public class product {
	String category;
	String search_str;
	int quantity;
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSearch_str() {
		return search_str;
	}
	public void setSearch_str(String search_str) {
		this.search_str = search_str;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
